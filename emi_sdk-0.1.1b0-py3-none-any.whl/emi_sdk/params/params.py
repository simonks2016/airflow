import json
from dataclasses import dataclass, field, asdict
from typing import List, Optional


@dataclass
class Param:

    def toJson(self):
        return json.dumps(self, default=lambda o: o.__dict__)

    @classmethod
    def from_json(cls, json_data: str) -> 'Param':
        data = json.loads(json_data)
        return cls(**data)

    def to_dict(self):
        # 将对象转换为字典
        return asdict(self)

@dataclass
class AddProgramParam(Param):
    program_id:str
    sort_number:int
    stage:str

@dataclass
class CreateVideoParam(Param):
    title:str
    description:str
    play_link:str
    thumb:str
    tags:List[str]
    program:Optional[AddProgramParam] = None

@dataclass
class AddEpisodesParam(Param):
    video_title:str
    video_description:str
    video_play_link:str
    source_from:str
    sort_number:int
    episode_stage:str

@dataclass
class CreateProgramParam(Param):
    title:str
    description:str
    show_subtitle:str
    poster:str
    thumb:str
    tags:List[str]
    price:float
    category_id:str
    episodes: List[AddEpisodesParam]
    is_adult:bool
    is_subscribe_program:bool


@dataclass
class BatchCreateVideosParam(Param):
    videos:List[CreateVideoParam]

@dataclass
class BatchCreateProgramsParam(Param):
    programs:List[CreateProgramParam]

@dataclass
class CreatePersonageParam(Param):
   name:str
   foreign_name:str
   alias:str
   occupation:str
   birth_date:str
   birth_place:str
   debut_date:str
   debut_place:str
   poster:str
   nationality:str
   gender:int
   description:str

@dataclass
class UploadParam(Param):
    file_name:str
    ext:str
    bind_video:Optional[str] = None

@dataclass
class SearchParam(Param):
    sort_by:str
    keyword:str
    page:int
    start_time:str
    end_time:str
