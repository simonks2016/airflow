from typing import List

from requests import post
from emi_sdk.client.client import OpenClient
from emi_sdk.params import BatchCreateProgramsParam, \
    BatchCreateVideosParam
from emi_sdk.params.params import SearchParam, CreateProgramParam
from emi_sdk.response import Response


class StudioClient(OpenClient):


    def showAccessToken(self):
        return self._access_token

    def SearchVideo(self, param:SearchParam,callback = None):

        if self._access_token is None:
            while 3:
                # 连接新客户端
                self.connect()
                # 假如不为空
                if self._access_token is not None:
                    break
                else:
                    return False

        result = post(f"{self._host}/studio/search/video", json=param.to_dict(), headers={
            'Authorization': self._access_token,
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Connection': 'keep-alive',
            'Content-Type': 'application/x-www-form-urlencoded',
        })
        return self.__handleResult(result, callback=callback)

    def SearchProgram(self, param:SearchParam,callback = None):

        if self._access_token is None:
            while 3:
                # 连接新客户端
                self.connect()
                # 假如不为空
                if self._access_token is not None:
                    break
                else:
                    return False

        result = post(f"{self._host}/studio/search/video", json=param.to_dict(), headers={
            'Authorization': self._access_token,
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Connection': 'keep-alive',
            'Content-Type': 'application/x-www-form-urlencoded',
        })
        return self.__handleResult(result, callback=callback)


    def BatchCreateVideos(self, params:BatchCreateVideosParam, callback=None):

        if not params:
            return False  # 确保 `param` 不

        if self._access_token is None:
            for _ in range(3):  # 最多尝试 3 次获取 token
                self.connect()
                if self._access_token:
                    break
            else:
                return False  # 失败则返回 False

        # 发送请求
        result = post(
            f"{self._host}/studio/video/batch_create",
            json=params.to_dict(),  # 发送 JSON 数据
            headers={
                'Authorization': f'Bearer {self._access_token}',  # 需要 `Bearer`
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'zh-CN,zh;q=0.9',
                'Connection': 'keep-alive',
                'Content-Type': 'application/json',  # 指定 `Content-Type`
            },
            cookies=self._cookies
        )

        # 处理请求结果
        return self.__handleResult(result, callback=callback)

    def BatchCreatePrograms(self, param:BatchCreateProgramsParam, callback=None) -> bool:

        if param is None :return False

        if self._access_token is None:
            while 3:
                # 连接新客户端
                self.connect()
                # 假如不为空
                if self._access_token is not None:
                    break
                else:
                    return False
        # post 数据
        result = post(f"{self._host}/studio/program/batch_create", json=param.to_dict() , headers={
            'Authorization': f'Bearer {self._access_token}',  # 需要 `Bearer`
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Connection': 'keep-alive',
            'Content-Type': 'application/json',
        }, cookies=self._cookies)

        return self.__handleResult(result, callback=callback)

    def CreateProgram(self,param:CreateProgramParam, callback=None) -> bool:

        if param is None: return False

        if self._access_token is None:
            while 3:
                # 连接新客户端
                self.connect()
                # 假如不为空
                if self._access_token is not None:
                    break
                else:
                    return False
        # post 数据
        result = post(f"{self._host}/studio/program/create", json=param.to_dict(), headers={
            'Authorization': f'Bearer {self._access_token}',  # 需要 `Bearer`
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Connection': 'keep-alive',
            'Content-Type': 'application/json',
        }, cookies=self._cookies)

        return self.__handleResult(result, callback=callback)

    def __handleResult(self, result, callback=None):

        if result.status_code == 200:
            resp = Response.from_json(result.text)
            #
            if resp.code == 200:
                if callback is not None:
                    # 使用回调函数
                    callback(resp.content)
                return True
            else:
                errorMsg = resp.message.get("error_message")
                print(f"错误原因:{errorMsg}")
                return False
        else:
            print(f"返回错误代码:{result.status_code}")
            return False
