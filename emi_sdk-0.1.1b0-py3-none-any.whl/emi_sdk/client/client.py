from typing import List
from requests import post
from emi_sdk import Response
from emi_sdk.response.video import VideoDataModel


class OpenClient:
    host = None
    port = None
    username = None
    password = None
    access_token = None

    def __init__(self, host, username, password):

        self._access_token = None
        self._host = host
        self._username = username
        self._password = password
        self._cookies = None

    def connect(self):

        response = post(f"{self._host}/login", data={
            'account': self._username,
            'password': self._password,
            'by': "account",
            'page_token': "aaaa"
        }, headers={
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Connection': 'keep-alive',
            'Content-Type': 'application/x-www-form-urlencoded',
        })

        if response.status_code == 200:
            try:
                resp = Response.from_json(response.text)

                if resp.code == 200:
                    self._access_token = resp.content.get("access_token")
                    self._cookies = response.cookies
                else:
                    print(resp.message.get("error_message"))

            except Exception as e:
                print(f"错误原因：{e}")
        else:
            print(f"返回错误代码:{response.status_code}")

    def GetVideosList(self,page:int)->List[VideoDataModel]:

        response = post(f"{self._host}/video/list",data={
            "page":page
        },headers={
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Connection': 'keep-alive',
            'Content-Type': 'application/x-www-form-urlencoded',
        },cookies=self._cookies)

        if response.status_code == 200:
            try:
                resp = Response.from_json(response.text)
                if resp.code == 200:
                    if isinstance(resp.content, list):
                        return [VideoDataModel.from_dict(video) for video in resp.content]
                    elif isinstance(resp.content, dict):
                        return [VideoDataModel.from_dict(resp.content)]
                    else:
                        return []
                else:
                    return []
            except Exception as e:
                print("错误原因:"+str(e))
                return []
        else:
            print("错误代码："+str(response.status_code))
            return []




