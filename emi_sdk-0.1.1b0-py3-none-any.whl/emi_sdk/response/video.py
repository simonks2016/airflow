from dataclasses import dataclass, fields


@dataclass
class VideoDataModel:
    id:str
    title:str
    description:str
    thumb:str
    published:str

    @classmethod
    def from_dict(cls, data) -> "VideoDataModel":

        field_names = {f.name for f in fields(cls)}
        filtered_data = {k: v for k, v in data.items() if k in field_names}
        return cls(**filtered_data)

