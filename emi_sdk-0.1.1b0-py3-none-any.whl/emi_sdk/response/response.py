import dataclasses
from dataclasses import dataclass
from typing import Any, Dict

from emi_sdk.params import Param


@dataclass
class Response(Param):

    code:int
    content:Any
    message:Dict[str,str]
    redirect_url:str
    redirect_params:str
    is_use_caching:bool
