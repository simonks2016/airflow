# 先将子模块本身 import 进来，以便在 your_package 顶层可以访问到
from . import client
from . import params
from . import response

# 再把子模块的所有已公开成员(*导入)，合并到当前命名空间下
from .client import *
from .params import *
from .response import *

# 声明你要在顶层导出的名称
# 这里先把子模块本身（client、params、response）列进去
__all__ = ['client', 'params', 'response']

# 然后把各子模块的 __all__ (已在子模块中定义好的) 合并到顶层
__all__.extend(client.__all__)
__all__.extend(params.__all__)
__all__.extend(response.__all__)

# 版本号可放在这里
__version__ = '0.1.1 Beta'


